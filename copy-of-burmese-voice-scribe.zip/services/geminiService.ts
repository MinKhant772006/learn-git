import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

// System instruction to ensure output is strictly Burmese text
const SYSTEM_INSTRUCTION = `
You are an expert Burmese transcriber. 
Your task is to listen to the audio provided and transcribe it exactly into written Burmese (Myanmar language).
- Output ONLY the Burmese text. 
- Do not add any English translation, introductory phrases, or conversational fillers.
- Do not add markdown unless strictly necessary for paragraph separation.
- If the audio is unclear, try to transcribe the most likely Burmese phrases.
- Ensure the spelling and grammar align with formal or standard colloquial Burmese depending on the speaker's tone.
`;

export const transcribeAudio = async (base64Audio: string, mimeType: string): Promise<string> => {
  if (!API_KEY) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash', // Flash is fast and efficient for transcription
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Audio
            }
          },
          {
            text: "Transcribe this audio into Burmese text."
          }
        ]
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.2, // Low temperature for more deterministic/accurate transcription
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No transcription generated.");
    }

    return text.trim();
  } catch (error) {
    console.error("Gemini Transcription Error:", error);
    throw error;
  }
};