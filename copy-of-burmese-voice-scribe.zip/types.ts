export interface TranscriptionItem {
  id: string;
  text: string;
  timestamp: number;
}

export enum RecordingStatus {
  IDLE = 'IDLE',
  RECORDING = 'RECORDING',
  PROCESSING = 'PROCESSING',
  ERROR = 'ERROR',
}

export type MimeType = 'audio/webm' | 'audio/mp4' | 'audio/wav';