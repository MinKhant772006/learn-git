import React, { useState, useRef, useEffect } from 'react';
import { RecordButton } from './components/RecordButton';
import { TranscriptionCard } from './components/TranscriptionCard';
import { ThemeToggle } from './components/ThemeToggle';
import { RecordingStatus, TranscriptionItem } from './types';
import { getSupportedMimeType, blobToBase64 } from './utils/audioUtils';
import { transcribeAudio } from './services/geminiService';
import { Sparkles, MessageSquareQuote, Mic } from 'lucide-react';

const App: React.FC = () => {
  const [status, setStatus] = useState<RecordingStatus>(RecordingStatus.IDLE);
  const [transcriptions, setTranscriptions] = useState<TranscriptionItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  // Theme state
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' || 
             (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });

  // Refs for audio handling
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);

  // Apply theme class
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mimeType = getSupportedMimeType();
      if (!mimeType) {
        throw new Error("No supported audio mime type found in this browser.");
      }

      const mediaRecorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = handleRecordingStop;

      mediaRecorder.start();
      setStatus(RecordingStatus.RECORDING);
    } catch (err: any) {
      console.error("Error starting recording:", err);
      setError(err.message || "Could not access microphone.");
      setStatus(RecordingStatus.ERROR);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
      setStatus(RecordingStatus.PROCESSING);
    }
  };

  const handleRecordingStop = async () => {
    try {
      const mimeType = mediaRecorderRef.current?.mimeType || 'audio/webm';
      const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
      
      if (audioBlob.size === 0) {
        setError("No audio recorded.");
        setStatus(RecordingStatus.IDLE);
        return;
      }

      const base64Audio = await blobToBase64(audioBlob);
      const text = await transcribeAudio(base64Audio, mimeType);

      const newItem: TranscriptionItem = {
        id: crypto.randomUUID(),
        text,
        timestamp: Date.now(),
      };

      setTranscriptions(prev => [newItem, ...prev]);
      setStatus(RecordingStatus.IDLE);
    } catch (err: any) {
      console.error("Processing error:", err);
      setError("Failed to transcribe audio. Please try again.");
      setStatus(RecordingStatus.ERROR);
      
      setTimeout(() => {
        if (status === RecordingStatus.ERROR) {
          setStatus(RecordingStatus.IDLE);
        }
      }, 3000);
    }
  };

  const toggleRecording = () => {
    if (status === RecordingStatus.IDLE || status === RecordingStatus.ERROR) {
      startRecording();
    } else if (status === RecordingStatus.RECORDING) {
      stopRecording();
    }
  };

  const deleteTranscription = (id: string) => {
    setTranscriptions(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden transition-colors duration-500">
      
      {/* Background Gradients */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-teal-200/20 dark:bg-teal-900/10 blur-[100px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-200/20 dark:bg-indigo-900/10 blur-[100px]" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 transition-all duration-300 backdrop-blur-md border-b border-slate-200/50 dark:border-slate-800/50 bg-white/70 dark:bg-slate-950/70">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-tr from-teal-500 to-teal-700 p-2.5 rounded-xl shadow-lg shadow-teal-500/20">
              <MessageSquareQuote className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight leading-none">
                Burmese <span className="text-teal-600 dark:text-teal-400">Voice Scribe</span>
              </h1>
              <span className="text-[10px] font-semibold tracking-wider text-slate-500 dark:text-slate-400 uppercase">
                AI Transcription
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             <div className="hidden sm:block text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700">
              Gemini 2.5 Flash
            </div>
            <ThemeToggle isDark={isDark} toggle={toggleTheme} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-2xl mx-auto w-full px-4 py-8 flex flex-col items-center relative z-10">
        
        {/* Intro Text */}
        {transcriptions.length === 0 && status === RecordingStatus.IDLE && (
          <div className="text-center mt-12 mb-12 max-w-md animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="w-20 h-20 rounded-3xl mx-auto flex items-center justify-center mb-6 bg-gradient-to-br from-white to-slate-100 dark:from-slate-800 dark:to-slate-900 shadow-xl shadow-slate-200 dark:shadow-slate-950/50 border border-slate-200 dark:border-slate-700">
              <Mic className="w-10 h-10 text-teal-500 dark:text-teal-400" />
            </div>
            <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-4 tracking-tight">Speak. Transcribe. Copy.</h2>
            <p className="text-slate-500 dark:text-slate-400 text-lg leading-relaxed">
              Experience high-precision Burmese speech-to-text. Just tap the button and speak naturally.
            </p>
          </div>
        )}

        {/* Status Messages */}
        {error && (
          <div className="mb-8 px-5 py-4 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 rounded-2xl text-sm font-medium animate-in slide-in-from-top-2 shadow-sm w-full max-w-md text-center">
            {error}
          </div>
        )}

        {/* Recording Control */}
        <div className={`mb-12 transition-all duration-700 ease-out ${transcriptions.length > 0 ? 'order-first scale-90' : 'mt-4'}`}>
          <RecordButton status={status} onClick={toggleRecording} />
        </div>

        {/* Transcription List */}
        <div className="w-full space-y-6">
          {transcriptions.map((item) => (
            <div key={item.id} className="animate-in slide-in-from-bottom-8 duration-500 fill-mode-backwards">
              <TranscriptionCard item={item} onDelete={deleteTranscription} />
            </div>
          ))}
        </div>

        {/* History Hint */}
        {transcriptions.length > 3 && (
           <div className="mt-12 text-slate-400 dark:text-slate-500 text-sm flex items-center space-x-2 bg-white/50 dark:bg-slate-900/50 px-4 py-2 rounded-full backdrop-blur-sm">
             <Sparkles className="w-4 h-4" />
             <span>Scroll for history</span>
           </div>
        )}
      </main>
      
      <footer className="py-8 text-center text-slate-400 dark:text-slate-600 text-sm relative z-10">
        <p>© {new Date().getFullYear()} Burmese Voice Scribe</p>
      </footer>
    </div>
  );
};

export default App;