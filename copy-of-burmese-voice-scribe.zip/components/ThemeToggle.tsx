import React from 'react';
import { Moon, Sun } from 'lucide-react';

interface ThemeToggleProps {
  isDark: boolean;
  toggle: () => void;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ isDark, toggle }) => {
  return (
    <button
      onClick={toggle}
      className="p-2.5 rounded-full transition-all duration-300 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border border-slate-200 dark:border-slate-700 hover:scale-110 active:scale-95 text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 shadow-sm"
      aria-label="Toggle theme"
    >
      <div className="relative w-5 h-5">
        <Sun className={`absolute inset-0 w-full h-full transition-all duration-500 rotate-0 scale-100 ${isDark ? 'rotate-90 scale-0 opacity-0' : ''}`} />
        <Moon className={`absolute inset-0 w-full h-full transition-all duration-500 rotate-90 scale-0 opacity-0 ${isDark ? 'rotate-0 scale-100 opacity-100' : ''}`} />
      </div>
    </button>
  );
};