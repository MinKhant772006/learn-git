import React, { useState } from 'react';
import { Copy, Check, Trash2 } from 'lucide-react';
import { TranscriptionItem } from '../types';

interface TranscriptionCardProps {
  item: TranscriptionItem;
  onDelete: (id: string) => void;
}

export const TranscriptionCard: React.FC<TranscriptionCardProps> = ({ item, onDelete }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(item.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="group relative bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm hover:shadow-lg dark:hover:shadow-teal-900/20 border border-slate-100 dark:border-slate-800 transition-all duration-300">
      
      {/* Decorative gradient blob behind text */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-teal-50 dark:bg-teal-900/20 rounded-bl-[100px] rounded-tr-3xl -z-0 opacity-50 transition-opacity group-hover:opacity-100"></div>

      <div className="relative z-10">
        <div className="flex justify-between items-start mb-4">
          <span className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded-md">
            {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          <div className="flex space-x-2 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <button
              onClick={handleCopy}
              className={`
                p-2 rounded-full transition-all duration-200 
                ${copied 
                  ? 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300' 
                  : 'text-slate-400 hover:text-teal-600 dark:text-slate-500 dark:hover:text-teal-400 hover:bg-teal-50 dark:hover:bg-slate-800'
                }
              `}
              title="Copy to clipboard"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={() => onDelete(item.id)}
              className="p-2 text-slate-400 hover:text-rose-600 dark:text-slate-500 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-full transition-colors"
              title="Delete"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
        
        <p className="text-xl md:text-2xl leading-relaxed text-slate-800 dark:text-slate-200 font-burmese break-words whitespace-pre-wrap">
          {item.text}
        </p>
      </div>
    </div>
  );
};