import React from 'react';
import { Mic, Square, Loader2 } from 'lucide-react';
import { RecordingStatus } from '../types';

interface RecordButtonProps {
  status: RecordingStatus;
  onClick: () => void;
}

export const RecordButton: React.FC<RecordButtonProps> = ({ status, onClick }) => {
  const isRecording = status === RecordingStatus.RECORDING;
  const isProcessing = status === RecordingStatus.PROCESSING;

  return (
    <div className="relative group">
      {/* Outer Glow Ring for Recording state */}
      <div 
        className={`absolute inset-0 rounded-full blur-xl transition-all duration-500
          ${isRecording 
            ? 'bg-rose-500/40 dark:bg-rose-500/30 scale-150 animate-pulse' 
            : 'bg-teal-500/0 scale-100'
          }`} 
      />

      <button
        onClick={isProcessing ? undefined : onClick}
        disabled={isProcessing}
        className={`
          relative z-10 flex items-center justify-center w-24 h-24 rounded-full transition-all duration-300 shadow-2xl border-4
          ${isRecording 
            ? 'bg-gradient-to-br from-rose-500 to-red-600 border-rose-300 dark:border-rose-800 scale-110' 
            : isProcessing
              ? 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 cursor-not-allowed'
              : 'bg-gradient-to-br from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 border-teal-200 dark:border-teal-800 hover:scale-105'
          }
        `}
        aria-label={isRecording ? "Stop Recording" : "Start Recording"}
      >
        <div className={`transition-colors duration-300 ${isProcessing ? 'text-slate-400 dark:text-slate-500' : 'text-white'}`}>
          {isProcessing ? (
            <Loader2 className="w-10 h-10 animate-spin" />
          ) : isRecording ? (
            <Square className="w-8 h-8 fill-current drop-shadow-md" />
          ) : (
            <Mic className="w-10 h-10 drop-shadow-md" />
          )}
        </div>
        
        {/* Inner ring for depth */}
        <div className="absolute inset-2 rounded-full border border-white/20 dark:border-black/10 pointer-events-none"></div>
      </button>
      
      <div className={`
        absolute left-1/2 -translate-x-1/2 -bottom-14 whitespace-nowrap font-medium text-sm px-3 py-1 rounded-full backdrop-blur-md border transition-all duration-300
        ${isRecording 
          ? 'text-rose-600 dark:text-rose-400 bg-rose-50/50 dark:bg-rose-900/20 border-rose-100 dark:border-rose-800' 
          : isProcessing
            ? 'text-slate-500 dark:text-slate-400 bg-slate-100/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
            : 'text-slate-600 dark:text-slate-300 bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
        }
      `}>
        {isRecording ? "Tap to Stop" : isProcessing ? "Transcribing..." : "Tap to Speak"}
      </div>
    </div>
  );
};